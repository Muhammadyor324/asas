import React from 'react';

interface LoveMeterProps {
  level: number;
}

const LoveMeter: React.FC<LoveMeterProps> = ({ level }) => {
  return (
    <div className="w-full px-4 py-2 bg-black/40 backdrop-blur-md border-b border-white/10 sticky top-0 z-50">
      <div className="flex justify-between items-center mb-1">
        <span className="text-xs font-bold text-pink-400 uppercase tracking-widest">
          SYNC RATE
        </span>
        <span className="text-xs font-mono text-pink-300">{level}%</span>
      </div>
      <div className="w-full h-2 bg-gray-800 rounded-full overflow-hidden relative">
        <div 
          className="h-full bg-gradient-to-r from-purple-500 via-pink-500 to-red-500 transition-all duration-1000 ease-out animate-glow"
          style={{ width: `${level}%` }}
        />
        {/* Animated Scanline effect */}
        <div className="absolute top-0 bottom-0 w-2 bg-white/50 blur-[2px] animate-[float_2s_linear_infinite]" style={{left: `${level}%`}} />
      </div>
    </div>
  );
};

export default LoveMeter;
