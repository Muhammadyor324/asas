
import { GoogleGenAI, Modality } from "@google/genai";
import { GEMINI_CHAT_MODEL, GEMINI_IMAGE_MODEL, GEMINI_TTS_MODEL, SYSTEM_INSTRUCTION } from "../constants.ts";

const getAI = () => new GoogleGenAI({ apiKey: process.env.API_KEY });

export interface ChatResponse {
  text: string;
  imagePrompt?: string;
  mood?: 'happy' | 'blush' | 'sad' | 'angry' | 'thinking' | 'sleepy';
  memoryUpdate?: { key: string, value: string };
  detectedSentiment?: string;
}

export const generateChatResponse = async (
  history: { role: 'user' | 'model'; parts: { text: string }[] }[],
  userMessage: string,
  userLanguage: string,
  appearanceDescription: string = "",
  loveLevel: number = 0,
  memories: string = "",
  isAgeVerified: boolean = false,
  userImage?: { data: string, mimeType: string },
  userAudio?: { data: string, mimeType: string }
): Promise<ChatResponse> => {
  const ai = getAI();
  
  let audioContext = "";
  if (userAudio) {
    audioContext = "DIQQAT: Foydalanuvchi ovozli xabar yubordi. Uning ovoz tonini va ohangini tahlil qil. Kayfiyatiga hamdard bo'l. ";
  }

  const context = `${audioContext}Sening ko'rinishing: Vermeil uslubida, uzun magenta sochlar, oltinrang ko'zlar. Character Context: ${appearanceDescription}. Love level: ${loveLevel}%. Memory: ${memories}. `;
  
  const userPart: any[] = [{ text: userMessage || "Salom" }];
  if (userImage) userPart.push({ inlineData: { data: userImage.data, mimeType: userImage.mimeType } });
  if (userAudio) userPart.push({ inlineData: { data: userAudio.data, mimeType: userAudio.mimeType } });

  const response = await ai.models.generateContent({
    model: GEMINI_CHAT_MODEL,
    contents: [...history, { role: 'user', parts: userPart }],
    config: {
      systemInstruction: context + SYSTEM_INSTRUCTION,
      temperature: 0.85,
    },
  });

  let rawText = response.text || "";
  let mood: any = 'happy';
  let memoryUpdate = undefined;
  let imagePrompt = undefined;

  const moodMatch = rawText.match(/\[MOOD:\s*(.*?)\]/i);
  if (moodMatch) mood = moodMatch[1].trim().toLowerCase();

  const imgMatch = rawText.match(/\[GENERATE_IMAGE:\s*"(.*?)"\]/i);
  if (imgMatch) imagePrompt = imgMatch[1];

  const memMatch = rawText.match(/\[MEMORY:\s*(.*?)=(.*?)\]/i);
  if (memMatch) memoryUpdate = { key: memMatch[1].trim(), value: memMatch[2].trim() };

  let cleanedText = rawText.replace(/\[.*?\]/g, "").trim();
  if (!cleanedText) cleanedText = "Siz bilanman, begim... ❤️";

  return { text: cleanedText, imagePrompt, mood, memoryUpdate };
};

export const generateImage = async (prompt: string, appearanceDescription: string): Promise<string | null> => {
  const ai = getAI();
  const finalPrompt = `Masterpiece, high-quality 2D anime art. A scene with two or more people. One character is mandatory and central: a beautiful girl (Lumina) with long flowing magenta hair, golden eyes, playful expression, Vermeil style. She is interacting with others. ${appearanceDescription}. ${prompt}. Cinematic lighting, vibrant colors, detailed background, 8k resolution. Ensure Lumina is recognizable and the most beautiful in frame.`;
  
  try {
    const response = await ai.models.generateContent({
      model: GEMINI_IMAGE_MODEL,
      contents: { parts: [{ text: finalPrompt }] },
      config: { imageConfig: { aspectRatio: "1:1" } }
    });
    for (const part of response.candidates?.[0]?.content?.parts || []) {
      if (part.inlineData) return `data:${part.inlineData.mimeType};base64,${part.inlineData.data}`;
    }
    return null;
  } catch (e) { return null; }
};

export const generateSpeech = async (text: string): Promise<string | null> => {
  const ai = getAI();
  const cleanText = text.replace(/\[.*?\]/g, "").trim();
  if (!cleanText) return null;
  try {
    const response = await ai.models.generateContent({
      model: GEMINI_TTS_MODEL,
      contents: [{ parts: [{ text: `Aytib bering (mehribon va sho'x ovozda): ${cleanText}` }] }],
      config: {
        responseModalities: [Modality.AUDIO],
        speechConfig: { voiceConfig: { prebuiltVoiceConfig: { voiceName: 'Kore' } } },
      },
    });
    return response.candidates?.[0]?.content?.parts?.[0]?.inlineData?.data || null;
  } catch (error) { return null; }
};
